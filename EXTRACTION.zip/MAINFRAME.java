
public class MAINFRAME {
    public static void main(String [] args){
        Enter frame =new Enter();
        frame.setVisible(true);
        frame.setBounds(460, 240, 1000, 600);
        frame.setUndecorated(true);
        
    }
    
}
